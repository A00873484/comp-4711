Team: Vietnam
Team members: Danny Lieu & Thanh Lai
Project: COMP4711 Lab 07 exercise
Instructor: Jim Parry

What we have completed: 80%
	+ Can receive the origin and destination location to give the schedule
	+ The origin and depart time formatting nice.

What we haven't completed: Error messages