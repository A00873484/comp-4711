<p class="lead">
    Available ports
</p>
<table class="table">
    <tr>
        <td>Code</td>
        <td>Name</td>
    </tr>
    {ports}
    <tr>
        <td>{code}</td>
        <td>{name}</td>
    </tr>
    {/ports}
</table>