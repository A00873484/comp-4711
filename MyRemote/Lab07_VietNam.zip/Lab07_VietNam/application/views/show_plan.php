<p class="lead">
    Your Custom Travel Plan
</p>
<table class="table">
    <tr><td>From {source} to {destination}</td></tr>
    <tr>
        <td>Sails on</td>
        <td>Leaves</td>
        <td>Arrives</td>
        <td>Stops</td>
    </tr>
    {departures}
</table>