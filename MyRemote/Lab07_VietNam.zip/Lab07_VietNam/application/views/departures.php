<tr>
    <td>{sailson}</td>
    <td>{departure_time}</td>
    <td>{arrival_time}</td>
    <td>{stops_on_the_way}</td>    
</tr>
