Daniel Engelhard, Jay Huang

All finished other then update in the rest