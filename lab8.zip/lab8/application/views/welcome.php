<p class="lead">
    <a href="/welcome/lab5start" class="btn btn-large btn-primary">Lab 5</a>    
    <a href="/planner" class="btn btn-large btn-primary">Lab 7</a>    
</p>

