
<form action="/admin/post5/{num}" method="post">
<p>Jim's Joint Maintenance</p>

{code}
{name}
{description}
{price}
{category}
{picture}
{submit}
<br>


</form>