<?php
/*
 * Menu navbar, just an unordered list
 */
?>
<ul>
    {menudata}
    <li><a class="navbar" href="{menulink}">{menuname}</a></li>
    {/menudata}
</ul>
