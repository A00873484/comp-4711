<?php
/*
 * Menu navbar, just an unordered list
 */
?>
<ul class="nav">
    {menudata}
    <li><a href="{functionlink}" class="btn btn-large btn-primary">{function}</a></li>
    {/menudata}
</ul>
