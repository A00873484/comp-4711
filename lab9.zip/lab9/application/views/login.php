<form action="/userlogin/submit" method="post">
<p>Login</p>

User Name: <input type="text" name="username" value = ""><br>
Password: <input type="text" name="password" value = ""><br>
<input type="submit" value="Login">

