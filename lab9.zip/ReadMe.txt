Daniel Engelhard, Jay Huang

All finished except for the bonus