<?php
echo phpinfo();exit();
//echo $_SERVER['SEVER_NAME'];

$json_obj = '{	
"firstName": "John",
"lastName" : "Smith",
"age"      : 25,
"address"  :     {
         "streetAddress": "21 2nd Street",
         "city"         : "New York",
         "state"        : "NY",
         "postalCode"   : "10021"
     },
"phoneNumber":     [
         { "type"  : "home",
           "number": "212 555-1234"
         },
         { "type"  : "fax",
           "number": "646 555-4567"
         }
     ]
 }';
echo $json_obj."<br/><br/>";

$json2 = json_decode($json_obj,false);
echo var_dump($json2)."<br/><br/>";


$json3 = json_decode($json_obj,true);
echo var_dump($json3)."<br/><br/>";


$json4 = json_encode($json3);
echo var_dump($json4)."<br/><br/>";

$json5 = json_encode($json2);
echo var_dump($json5)."<br/><br/>";

$v1 = '<?xml version="1.0" encoding="UTF-8"?>
<contacts>
    <contact id="1">
        <name>John Doe</name>
        <phone>123-456-7890</phone>
        <address>
            <street>123 JFKStreet</street>
            <city>Any Town</city>
            <state>Any State</state>
            <zipCode>12345</zipCode>
        </address>
    </contact>
</contacts>
';
$xml = simplexml_load_string($v1);
echo var_dump(json_encode($xml))."<br/><br/>";

echo 'woohoo';

$v1 = new stdClass();
$v1->name = "Jim";
$v1->age = 29;
echo var_dump($v1).'<br/><br/>';
$w1 = get_object_vars($v1);
echo var_dump($w1).'<br/><br/>';
$w2 = (array) $v1;
echo var_dump($w2).'<br/><br/>';

$v4 = (object)$w2;
echo var_dump($v4).'<br/><br/>';

$a1 = (object) $xml;
echo var_dump($a1).'<br/><br/>';
$a2 = (array) $xml;
echo var_dump($a2).'<br/><br/>';
