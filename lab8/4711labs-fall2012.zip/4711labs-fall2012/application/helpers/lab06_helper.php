<?php

/**
 * A helper function to extract tourism expense data for presentation as minor 
 * categories insid major categories, with grand totals.
 * 
 * This code is ugly as sin, partly because it is a helper function, and
 * partly because refactoring will wait until this gets moved into a CI model.
 * 
 * @param   (string) $filename   The name of the XML document
 */
function extract_expenditures($filename) {
    $xml = simplexml_load_file($filename);

    // setup overall presentation arraya
    $return_array = array(
        "report_title" => 'Tourism Expenditures',
        'major_category' => array(),
        "q1" => 0,
        "q2" => 0,
        "q3" => 0,
        "q4" => 0
    );

    // build the major category arrays
    foreach ($xml->area as $major_category) {
        // setup a major category arraya
        $major_cat_array = array(
            "minor_category" => array(),
            "name" => (string) $major_category['name'],
            "q1" => 0,
            "q2" => 0,
            "q3" => 0,
            "q4" => 0,
        );
        // build the minor category arrays, if present
        if (isset($major_category->group))
            foreach ($major_category->group as $minor_category) {
                // setup a minor category array
                $minor_cat_array = array(
                    "name" => (string) $minor_category['name'],
                    "q1" => 0,
                    "q2" => 0,
                    "q3" => 0,
                    "q4" => 0,
                );
                // iterate over the expense detail items inside the minor category
                // this code assumes nested elements, one per period
                if (isset($minor_category->item))
                    foreach ($minor_category->item as $item)
                        foreach ($item->cell as $period) {
                            // we only want 2011 data
                            if ($period['year'] == 2011) {
                                // accumulate all 3 levels of totals at once
                                $minor_cat_array[strtolower('Q' . $period['quarter'])] += $period;
                                $major_cat_array[strtolower('Q' . $period['quarter'])] += $period;
                                $return_array[strtolower('Q' . $period['quarter'])] += $period;
                            }
                        }
                // alternate iteration, for those categories which do not have nested items
                else
                    foreach ($minor_category->cell as $period) {
                        // we only want 2011 data
                        if ($period['year'] == 2011) {
                            // accumulate all 3 levels of totals at once
                            $minor_cat_array[strtolower('Q' . $period['quarter'])] += $period;
                            $major_cat_array[strtolower('Q' . $period['quarter'])] += $period;
                            $return_array[strtolower('Q' . $period['quarter'])] += $period;
                        }
                    }
                // save the minor category nested inside a major category
                $major_cat_array['minor_category'][] = $minor_cat_array;
            }
        else
        // iterate over the cells directly inside a major group
            foreach ($major_category->cell as $period) {
                // we only want 2011 data
                if ($period['year'] == 2011) {
                    // accumulate all 3 levels of totals at once
                    $minor_cat_array[strtolower('Q' . $period['quarter'])] += $period;
                    $major_cat_array[strtolower('Q' . $period['quarter'])] += $period;
                    $return_array[strtolower('Q' . $period['quarter'])] += $period;
                }
            }

        // save the major category nested inside the outermost structure
        $return_array['major_category'][] = $major_cat_array;
    }
    // map the overall totals properly
    $return_array['total1'] = $return_array['q1'];
    $return_array['total2'] = $return_array['q2'];
    $return_array['total3'] = $return_array['q3'];
    $return_array['total4'] = $return_array['q4'];

    // and we are done
    return $return_array;
}
