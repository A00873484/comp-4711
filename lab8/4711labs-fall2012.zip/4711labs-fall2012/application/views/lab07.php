<?php
/*
 * View for lab 7 - process our document using a CI model
 * Explain what went into this lab.
 */
?>
<div>
    <div>
        This lab involved creating a CodeIgniter model for our tourism data,
        moving the lab 6 helper inside it, and then adding a couple of
        work methods to extract category codes and calculate annual totals
        for a selected one. <br/>
        Note: the original simplified report, but coming from the model, is
        shown in the "Report" tab above.
        <hr/>
        The categories below have been extracted from our model.
        Pick one, and click the "submit" button to see the annual expenditures for
        that category.<br/>
    </div>
    <div>
        <fieldset>
            <legend>Pick a category to see its annual expenditures</legend>
            <div>
                <form action="/lab07/work" method="post">
                    <select name="requested">
                        {categories}
                        <option value="{code}">{description}</option>
                        {/categories}
                    </select>
                    <br/>
                    Hit the button: <button type="submit">Go go go</button><br/>
                </form>
            </div>
        </fieldset>
        <fieldset>
            <legend>See your results here!</legend>
            <div>
                The total expenditures for {category} were {total}.
            </div>
        </fieldset>
    </div>
</div>