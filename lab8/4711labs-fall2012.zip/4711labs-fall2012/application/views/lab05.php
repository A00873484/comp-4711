<?php
/* 
 * View for lab 5 - constrain our XML wih a schema
 * Explain what went into this lab.
 */

?>
<div>
    This lab involved constraining our original XML document with a
    schema, using the CodeIgniter webapp framework we setup earlier.
    <hr/>
    The schema can be seen under the "Our Schema" tab above, and the bound XML data 
    under the "Our XML" tab.
    <hr/>
    Results of validating the XML against the schema:<br/>
    <b>{validation}</b>
</div>