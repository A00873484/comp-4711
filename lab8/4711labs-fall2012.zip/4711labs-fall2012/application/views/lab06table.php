<?php
/*
 * This view presents the tourism expenditures in simplified format.
 * This is just one possible presentation format, and probably
 * not the best, but it forces you to wrap your heads around transforming
 * your XML structure into something different.
 * 
 * This view expects six parameters:
 * report_title, major_category, q1, q2, q3, q4
 * q1 thru q4 hold the grand totals
 * 
 * major_category is itself an associative array, with:
 * name, minor_category, q1, q2, q3, q4
 * q1 thru q4 hold the major category totals
 * 
 * minor_category is itself an associative array, with:
 * name, q1, q2, q3, q4
 * q1 thru q4 hold the minor category values or totals
 * 
 * I have added some CSS classes for you to use
 */
?>
<div>
    <h1>{report_title}</h1>
    <table>
        <tr class="report_top">
            <th>Tourism Expenditures</th>
            <th>Q1 2011</th>
            <th>Q2 2011</th>
            <th>Q3 2011</th>
            <th>Q4 2011</th>
        </tr>
        {major_category}
        <tr class="report_major">
            <td>{name}</td>
        </tr>
        {minor_category}
        <tr class="report_minor">
            <td>{name}</td>
            <td>{q1}</td>
            <td>{q2}</td>
            <td>{q3}</td>
            <td>{q4}</td>
        </tr>
        {/minor_category}
        <tr class="report_major">
            <td>Total {name}</td>
            <td>{q1}</td>
            <td>{q2}</td>
            <td>{q3}</td>
            <td>{q4}</td>
        </tr>
        {/major_category}
        <tr class="report_bottom">
            <td>Total Tourism Expenditures</td>
            <td>{total1}</td>
            <td>{total2}</td>
            <td>{total3}</td>
            <td>{total4}</td>
        </tr>
    </table>
</div>
