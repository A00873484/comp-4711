<?php
/*
 * This is an internal view fragment that builds the top tabbed menu bar.
 * 
 * Generate a CSS tabbed menu.
 * This will be an unordered list, styled by a section of our stylesheet.
 */
?>
<ul class="basictab">
    {tabs}
    <li {selected}><a href="{link}">{desc}</a></li>
    {/tabs}
</ul>
