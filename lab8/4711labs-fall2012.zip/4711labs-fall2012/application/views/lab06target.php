<?php
/*
 * View for lab 3 - Show the original data.
 */
?>
<div>
    <img src="/assets/images/Simplified expenditures.png" />
</div>