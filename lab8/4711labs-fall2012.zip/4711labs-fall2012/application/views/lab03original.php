<?php
/*
 * View for lab 3 - Show the original data.
 */
?>
<div>
    <img src="/assets/images/Tourism expenditures.png" width="700" height="372"/>
</div>