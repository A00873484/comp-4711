<?php
/*
 * View for lab 10 
 */
?>
<div>
    <fieldset>
        <legend>Product List</legend>
        <div>
            <form action="/lab11/update/{code}" method="post">
                <table>
                    <tr>
                        <th>Field</th>
                        <th>Value</th>
                    </tr>
                    <tr><td>Code</td>
                        <td><input type="text" name="code" value="{code}" disabled="disabled"/></td></tr>
                    <tr><td>Name</td>
                        <td><input type="text" name="name" value="{name}"/></td></tr>
                    <tr><td>Line</td>
                        <td><input type="text" name="line" value="{line}"/></td></tr>
                    <tr><td>Scale</td>
                        <td><input type="text" name="scale" value="{scale}"/></td></tr>
                    <tr><td>Vendor</td>
                        <td><input type="text" name="vendor" value="{vendor}"/></td></tr>
                    <tr><td>Description</td>
                        <td><input type="text" name="description" value="{description}"/></td></tr>
                    <tr><td>Quantity</td>
                        <td><input type="text" name="quantity" value="{quantity}"/></td></tr>
                    <tr><td>Cost</td><td><input type="text" name="cost" value="{cost}"/></td></tr>
                    <tr><td>MSRP</td><td><input type="text" name="msrp" value="{msrp}"/></td></tr>
                </table>
                <input type="submit" value="Update product"/>
            </form>

            <a href="/lab11/delete/{code}">Delete this product</a>
        </div>
    </fieldset>
</div>