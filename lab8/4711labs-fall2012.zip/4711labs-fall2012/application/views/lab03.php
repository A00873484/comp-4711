<?php
/* 
 * View for lab 3 - setting up the generic lab work framework
 * Explain what went into this lab.
 */

?>
<div>
    This lab involved the setup of a generic CodeIgniter webapp framework, 
    to showcase the results of all of the Comp4711 labs. 
    This webapp will be added to as the term progresses.
    <hr/>
    Our labs this term are based on modeling tourism expenditures in Canada.
    The sample data we used can be seen under the "Original data" tab above,
    and the XML model for that data can be seen in the "Our XML" tab.
</div>