<?php
/*
 * View for lab 9 - explain what we did
 */
?>
<div>
    <div>
        Hello, {userName}.<br/>
        Upload a .CSV file containing the data for 2012 Q2...
        <hr/>
        <form enctype="multipart/form-data" action="/lab09update" method="post">
            <input type="file" name="userfile" size="20" />
            <br /><br />
            <input type="submit" value="upload" />
        </form>
        {error}
    </div>
</div>