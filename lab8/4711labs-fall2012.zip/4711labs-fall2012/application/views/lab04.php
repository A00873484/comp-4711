<?php
/* 
 * View for lab 4 - constrain our XML wih a DTD
 * Explain what went into this lab.
 */

?>
<div>
    This lab involved constraining our original XML document with a
    DTD, using the CodeIgniter webapp framework we setup earlier.
    <hr/>
    The DTD can be seen under the "Our DTD" tab above, and the bound XML data 
    under the "Our XML" tab.
    <hr/>
    Results of validating the XML against the DTD:<br/>
    <b>{validation}</b>
</div>