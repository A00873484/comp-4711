<?php
/* 
 * View for lab 6 - process our document using SimpleXML
 * Explain what went into this lab.
 */

?>
<div>
    This lab involved processing our original XML document, using SimpleXML,
    to produce a specific target view. Even though SimpleXML code does not
    belong outside of a model, our kind instructor, Jim, allowed us
    to put it into a helper function.
    The job was complicated because our mean instructor, Jim, insisted
    that we create a multi-dimensional array that would get passed on
    to a prescribed view, setup for template parsing. Yowsa!
    <hr/>
    The target view is shown under the "Target" tab above, and the results
    of our processing are shown in the "Results" tab.    
</div>