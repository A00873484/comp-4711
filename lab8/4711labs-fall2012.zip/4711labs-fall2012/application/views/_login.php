<?php
/*
 * Login form
 */
?>
<div>
    <fieldset>
        <legend>Login</legend>
        <div>
            <form action="/login" method="post">
                Userid: <input type="text" name="userid"/>
                <br/>
                Password: <input type="password" name="password"/>
                <br/><button type="submit">Login</button><br/>
            </form>
        </div>
    </fieldset>
</div>