<?php
/*
 * View for lab 9 - explain what we did
 */
?>
<div>
    <div>
        Upload a .CSV file containing the data for 2012 Q2...01
    </div>
 </div>