<?php
/*
 * Login form
 */
?>
<div>
    <fieldset>
        <legend>Logged in</legend>
        <div>
            You are currently logged in as {userName}.
        </div>
    </fieldset>
</div>