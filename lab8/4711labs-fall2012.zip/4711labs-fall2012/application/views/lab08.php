<?php
/*
 * View for lab 7 - process our document using a CI model
 * Explain what went into this lab.
 */
?>
<div>
    <div>
        This lab involved enhancing our CodeIgniter model, adding shadow methods
        for each of the current ones. The new methods do the same thing, but
        traverse the XML using xpath instead of conventional iteration.<br/>
        Note: the original simplified report, but coming from the model and
        using XPath for traversal, is
        shown in the "Report" tab above.
        <hr/>
        The categories below have been extracted from our model.
        Pick one, and click the "submit" button to see the annual expenditures for
        that category.<br/>
    </div>
    <div>
        <fieldset>
            <legend>Pick a category to see its annual expenditures</legend>
            <div>
                <form action="/lab08/work" method="post">
                    <select name="requested">
                        {categories}
                        <option value="{code}">{description}</option>
                        {/categories}
                    </select>
                    <br/>
                    Hit the button: <button type="submit">Go go go</button><br/>
                </form>
            </div>
        </fieldset>
        <fieldset>
            <legend>See your results here!</legend>
            <div>
                The total expenditures for {category} were {total}.
            </div>
        </fieldset>
    </div>
</div>