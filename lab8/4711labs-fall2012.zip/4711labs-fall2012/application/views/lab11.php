<?php
/*
 * View for lab 10 
 */
?>
<div>
    <fieldset>
        <legend>Product List</legend>
        <div>
            <table>
                <tr>
                    <th>Code</th>
                    <th>Description</th>
                    <th>On Hand</th>
                </tr>
                {products}
                <tr>
                    <td><a href="/lab11/work/{code}">{code}</a></td>
                    <td>{name}</td>
                    <td>{quantity}</td>
                </tr>
                {/products}
            </table>
        </div>
    </fieldset>
</div>