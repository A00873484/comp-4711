<?php
/*
 * View for lab 9 - explain what we did
 */
?>
<div>
    <div>
        This lab involved adding authentication, role-based access, file uploading, 
        and XML updating. 
        <hr/>
        The two tabs on the top menu bar right have been constrained to require
        the "admin" role. If you select them without logging in, you will be redirected back here.<br/>
    </div>
    {content}
</div>