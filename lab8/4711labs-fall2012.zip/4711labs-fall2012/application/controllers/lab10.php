<?php

/**
 * Controller for COMP4711 Lab 10.
 * This is the XML-RPC client.
 * This is identical to lab 8, except that we get presentation data from our "remote" XML server.
 */
class Lab10 extends Application {

    var $tabs = array('/lab10/' => 'Introduction', '/lab10/report' => 'Report');
    // the following tell where to find the hosted solution
    var $remote_server = 'comp4711.bcitxml.com';
    var $remote_port = 80;

    function __construct() {
        parent::__construct();

        $this->load->library('xmlrpc');
        // uncomment the next two lines if using yourself as the "remote"
//        $this->remote_server = $_SERVER['SERVER_NAME'];
//        $this->remote_port = $_SERVER['SERVER_PORT'];
        //----------------------------------------------------------------
        $this->xmlrpc->server('http://' . $this->remote_server . ':' . $this->remote_port . '/lab10server');

        $this->load->helper('display');
        $this->data['tabs'] = $this->tabs;
        $this->data['pagetitle'] = 'COMP4711 Lab 10 Solution';
        $this->data['category'] = '?';
        $this->data['total'] = '?';
//        $this->load->model('tourism');        // we no longer need the tourism model locally
        // uncomment the next line to see more info about response
//        $this->xmlrpc->set_debug(true);
    }

    /**
     * Default entry point.
     * No work to do - the story is told in the view.
     */
    function index() {
        $this->data['pagebody'] = 'lab10';
        $this->data['selected'] = '/lab10/';
        $this->data['categories'] = $this->go_get_cats();
        $this->render();
    }

    /**
     * Subcontroller: work.
     * Process the category selection form, and ask the model for the total.
     */
    function work() {
        $requested = $this->input->post('requested');
        $this->data['category'] = $requested;
        $this->data['total'] = $this->go_get_total($requested);
        $this->index();
    }

    /**
     * Subcontroller: report.
     * Present the results of our processing the XML.
     * Note that the view has been dictated :(
     * Further note that the presentation data is now extracted inside our model
     */
    function report() {
        $this->data['pagebody'] = 'lab06table';
        $this->data = array_merge($this->data, $this->go_get_all());
        $this->data['selected'] = '/lab08/report';
        $this->render();
    }

    /**
     * Use XML-RPC to retrieve the categories from a remote server. 
     */
    function go_get_cats() {
        $this->xmlrpc->method('server.categories');

        $request = array();
        $this->xmlrpc->request($request);

        if (!$this->xmlrpc->send_request()) {
            echo $this->xmlrpc->display_error();
            exit();
        }

        return $this->xmlrpc->display_response();
    }

    /**
     * Use XML-RPC to retrieve the category total from a remote server. 
     */
    function go_get_total($category) {
        $this->xmlrpc->method('server.category_totals');

        $request = array(
            $category,
            'struct'
        );
        $this->xmlrpc->request($request);

        if (!$this->xmlrpc->send_request()) {
            echo $this->xmlrpc->display_error();
            exit();
        }

        $answer = $this->xmlrpc->display_response();
        return $answer[0];
    }

    /**
     * Use XML-RPC to retrieve all the data from a remote server. 
     */
    function go_get_all() {
        $this->xmlrpc->method('server.all_data');

        $request = array();
        $this->xmlrpc->request($request);

        if (!$this->xmlrpc->send_request()) {
            echo $this->xmlrpc->display_error();
            exit();
        }

        $answer = $this->xmlrpc->display_response();
        return $answer;
    }

}

/* End of file lab10.php */
/* Location: ./application/controllers/lab10.php */