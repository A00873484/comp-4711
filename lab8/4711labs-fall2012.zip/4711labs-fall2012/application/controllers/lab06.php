<?php

/**
 * Controller for COMP4711 Lab 6
 */
class Lab06 extends Application {

    var $tabs = array('/lab06/' => 'Introduction', '/lab06/target' => 'Target',
        '/lab06/result' => 'Result');

    function __construct() {
        parent::__construct();
        $this->data['tabs'] = $this->tabs;
        $this->data['pagetitle'] = 'COMP4711 Lab 6 Solution';
    }

    /**
     * Default entry point.
     * No work to do - the story is told in the view.
     */
    function index() {
        $this->data['pagebody'] = 'lab06';
        $this->data['selected'] = '/lab06/';
        $this->render();
    }

    /**
     * Subcontroller: target.
     * Present the desired result
     */
    function target() {
        $this->data['pagebody'] = 'lab06target';
        $this->data['selected'] = '/lab06/target';
        $this->render();
    }

    /**
     * Subcontroller: result.
     * Present the results of our processing the XML.
     * Note that the view has been dictated :(
     */
    function result() {
        $this->data['pagebody'] = 'lab06table';
        $this->load->helper('lab06');
        $this->data = array_merge($this->data, extract_expenditures($this->config->item('DATA_FOLDER') . 'tourism05.xml'));

        $this->data['selected'] = '/lab06/result';
        $this->render();
    }

}

/* End of file lab06.php */
/* Location: ./application/controllers/lab06.php */