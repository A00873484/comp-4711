<?php

/**
 * Controller for COMP4711 Lab 9
 */
class Lab09upload extends Application {

    var $tabs = array('/lab09/' => 'Intro...', '/lab09upload' => 'Upload',
        '/lab09update' => 'Update');

    function __construct() {
        parent::__construct();
        $this->restrict('admin');
        $this->load->helper('display');
        $this->data['tabs'] = $this->tabs;
        $this->data['pagetitle'] = 'COMP4711 Lab 9 Solution';
        $this->data['error'] = "";
    }

    /**
     * Default entry point.
     * The story is told in the view, and the "one" and "two" functions
     * act as URLs to present the different XSL documents I made
     * as solutions, one for each perspective on the data.
     */
    function index() {
        $this->data['pagebody'] = 'lab09upload';
        $this->data['selected'] = '/lab09upload';
        $this->session->set_flashdata('target','/lab09upload');
        $this->session->set_flashdata('oops_target','/lab09');
        $this->render();
    }

}

/* End of file lab09.php */
/* Location: ./application/controllers/lab09.php */