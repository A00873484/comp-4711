<?php

/**
 * Controller for COMP4711 Lab 5
 */
class Lab05 extends Application {

    var $tabs = array('/lab05/' => 'Introduction', '/lab05/xml' => 'Our XML',
        '/lab05/schema' => 'Our Schema');

    function __construct() {
        parent::__construct();
        $this->data['tabs'] = $this->tabs;
        $this->data['pagetitle'] = 'COMP4711 Lab 5 Solution';
    }

    /**
     * Default entry point.
     * No work to do - the story is told in the view.
     */
    function index() {
        $this->data['pagebody'] = 'lab05';
        $this->data['selected'] = '/lab05/';
        $this->data['validation'] = validate_xml_schema($this->config->item('DATA_FOLDER').'tourism05.xml',
                $this->config->item('DATA_FOLDER').'tourism.xsd');
        $this->render();
    }

    /**
     * Subcontroller: schema.
     * Display the schema used to constrain out XML
     */
    function schema() {
        $this->data['pagebody'] = '_data';
        $this->data['subtitle'] = 'Schema to constrain tourismXX.xml';
        $this->data['contents'] = display_file($this->config->item('DATA_FOLDER') . 'tourism.xsd');
        $this->data['selected'] = '/lab05/schema';
        $this->render();
    }

    /**
     * Subcontroller: xml.
     * Display the XML data that we came up with
     */
    function xml() {
        $this->data['pagebody'] = '_data';
        $this->data['subtitle'] = 'Tourism XML bound to our schema';
        $this->data['contents'] = display_file($this->config->item('DATA_FOLDER') . 'tourism05.xml');

        $this->data['selected'] = '/lab05/xml';
        $this->render();
    }

}

/* End of file lab05.php */
/* Location: ./application/controllers/lab05.php */