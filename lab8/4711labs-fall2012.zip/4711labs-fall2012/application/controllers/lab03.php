<?php

/**
 * Controller for COMP4711 Lab 3
 */
class Lab03 extends Application {

    // This array creates the tabs at the top of the screen.  Each association
    // is the name of the tab, and the function to execute when clicked.
    var $tabs = array('/lab03/' => 'Introduction', '/lab03/original' => 'Original data',
        '/lab03/xml' => 'Our XML');

    function __construct() {
        parent::__construct();
        $this->data['tabs'] = $this->tabs;
        $this->data['pagetitle'] = 'COMP4711 Lab 3 Solution';
    }

    /**
     * Default entry point.
     * No work to do - the story is told in the view.
     */
    function index() {
        $this->data['pagebody'] = 'lab03';
        $this->data['selected'] = '/lab03/';
        $this->render();
    }

    /**
     * Subcontroller: original.
     * Display an image of the data we started with. 
     */
    function original() {
        $this->data['pagebody'] = 'lab03original';
        $this->data['selected'] = '/lab03/original';
        $this->render();
    }

    /**
     * Subcontroller: xml.
     * Display the XML data that we came up with
     */
    function xml() {
        $this->data['pagebody'] = '_data';
        $this->data['subtitle'] = 'Tourism Expenditures in Canada';
        $this->data['contents'] = display_file($this->config->item('DATA_FOLDER') . 'tourism03.xml');

        $this->data['selected'] = '/lab03/xml';
        $this->render();
    }

}

/* End of file lab02.php */
/* Location: ./application/controllers/lab02.php */