<?php

/**
 * R B A C - login control
 */
class Login extends Application {

    function __construct() {
        parent::__construct();
    }

    /**
     * Default entry point.
     * 
     * Validate userid and password, provided as POST parameters.
     * 
     * On error, redirect to either oops_target (flashdata) or /
     */
    function index() {
        $userid = $_POST['userid'];
        $password = $_POST['password'];
        $user = $this->users->get($userid);
        if ($user != null) {
            // valid user. let's check the password
            $md5 = md5($password);
            if ($md5 == $user->password) {
                // good to go
                $this->session->set_userdata('userID', $userid);
                $this->session->set_userdata('userName', $user->name);
                $this->session->set_userdata('userRole', $user->role);
                // send them off
                $target = $this->session->flashdata('target');
                if (!$target) {
                    redirect("/");
                } else
                    redirect($target);
            }
        }
        $this->session->sess_destropy();
        redirect("/");
    }

}

/* End of file lab10.php */
/* Location: ./application/controllers/lab10.php */