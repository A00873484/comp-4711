<?php

/**
 * XML-RPC for COMP4711 Lab 10
 * 
 */
class Lab10server extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->library('xmlrpc');
        $this->load->library('xmlrpcs');
        $this->load->model('tourism');
    }

    // Entry point to the XML-RPC server
    function index() {

        $config['functions']['server.categories'] = array('function' => 'Lab10server.handle_categories');
        $config['functions']['categories'] = array('function' => 'Lab10server.handle_categories');
        $config['functions']['server.category_totals'] = array('function' => 'Lab10server.handle_category_total');
        $config['functions']['category_totals'] = array('function' => 'Lab10server.handle_category_total');
        $config['functions']['server.all_data'] = array('function' => 'Lab10server.handle_everything');
        $config['object'] = $this;

        $this->xmlrpcs->initialize($config);
        $this->xmlrpcs->serve();
    }

    // Handle a category list requess
    function handle_categories($request) {
        $answer = $this->tourism->get_x_categories();

        $response = array();
        foreach ($answer as $row)
            $response[] = array($row, 'struct');
        $response = array($response, 'struct');

        return $this->xmlrpc->send_response($response);
    }

    // Handle a category list requess
    function handle_category_total($request) {
        $parms = $request->output_parameters();
        $category = $parms[0];

        $answer = (int) $this->tourism->get_x_total($category);

        $response = array(
            array($answer),
            'array');

        return $this->xmlrpc->send_response($response);
    }

    // Handle a request for all the data
    function handle_everything($request) {
        $parms = $request->output_parameters();

        $answer = $this->tourism->get_x_all();
//        print_r($answer);exit();
        $response = array();
        // we need a fancier embedding because of the multi-dimensional array
        foreach ($answer as $rowkey=>$row)
            if (is_array($row)) {
                $major = array();
                foreach ($row as $nest=>$nested)
                    if (is_array($nested)) {
                        $minor = array();
                        foreach ($nested as $innerkey=>$inner)
                            if (is_array($inner)) {
                                $innermost = array();
                                foreach ($inner as $deepest)
                                    $innermost[] = array($deepest, 'struct');
                                $minor[$innerkey] = array($innermost, 'struct');
                            }
                            else
                                $minor[$innerkey] = array($inner, 'struct');
                        $major[$nest] = array($minor, 'struct');
                    }
                    else
                        $major[$nest] = array($nested, 'struct');
                $response[$rowkey] = array($major, 'struct');
            }
            else
                $response[$rowkey] = $row;
        $response = array($response, 'struct');

        $response = xmlrpc_encode($answer);
        echo $response;exit();
        return $this->xmlrpc->send_response($response);
    }

}

/* End of file lab12serverX.php */
/* Location: ./application/controllers/lab12serverX.php */