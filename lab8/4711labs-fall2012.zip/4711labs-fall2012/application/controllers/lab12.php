<?php

/**
 * Controller for COMP4711 Lab 12
 * 
 * Note that I have used slightly different filenames than the lab called for,
 * as I have six solutions in one here. Selecting one of the tabs will
 * trigger an "index-like" page, connected to the XML-RPC server for a
 * specific XML structure, which will in turn connect to the same server
 * to get quarterly sales data, but the quarterly sales data is presented
 * by a single view.
 * 
 * I have used separate servers for each structure of data, to make it
 * easier to copy the solution most relevant to the reader.
 * 
 */
class Lab12 extends Application {

    var $tabs = array('/lab12/' => 'XML-RPC ...', '/lab12/prompt/1' => 'By Source',
        '/lab12/prompt/2' => 'By Vehicle', '/lab12/prompt/3' => 'As table',
        '/lab12/prompt/4' => 'As elements', '/lab12/prompt/5' => 'By quarter',
        '/lab12/prompt/6' => 'W/embedded');

    function __construct() {
        parent::__construct();
        $this->load->helper('display');
    }

    function index() {
        $this->data['pagetitle'] = 'COMP4711 Lab 12 Solution';
        $this->load->helper('url');
        $this->data['pagetitle'] = current_url();
        $this->data['pagebody'] = 'lab12';
        $this->data['selected'] = '/lab12/';
//        $this->data['tabs'] = $this->tabs;
        $this->data['pagebody'] = 'placeholder';
        $this->render();
    }

}

/* End of file lab12.php */
/* Location: ./application/controllers/lab12.php */