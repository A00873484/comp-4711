<?php

/**
 * R B A C - logout control
 */
class Logout extends Application {

    function __construct() {
        parent::__construct();
    }

    /**
     * Default entry point.
     * 
     * Good bye
     */
    function index() {
        $this->session->sess_destroy();
        redirect("/");
    }

}

/* End of file lab10.php */
/* Location: ./application/controllers/lab10.php */