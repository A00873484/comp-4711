<?php

/**
 * Controller for COMP4711 Lab 9
 */
class Lab09 extends Application {

    var $tabs = array('/lab09/' => 'Intro...', '/lab09upload' => 'Upload',
        '/lab09update' => 'Update');

    function __construct() {
        parent::__construct();
        $this->load->helper('display');
        $this->data['tabs'] = $this->tabs;
        $this->data['pagetitle'] = 'COMP4711 Lab 9 Solution';
    }

    /**
     * Default entry point.
     * The story is told in the view, and the "one" and "two" functions
     * act as URLs to present the different XSL documents I made
     * as solutions, one for each perspective on the data.
     */
    function index() {
        $this->data['pagebody'] = 'lab09';
        $this->data['selected'] = '/lab09/';
        $this->session->set_flashdata('target', '/lab09upload');
        $this->session->set_flashdata('oops_target', '/lab09');
        if ($this->loggedin())
            $this->data['content'] = $this->parser->parse('_loggedin', $this->data, true);
        else
            $this->data['content'] = $this->load->view('_login', $this->data, true);
        $this->render();
    }

}

/* End of file lab09.php */
/* Location: ./application/controllers/lab09.php */