<?php

/**
 * Controller for COMP4711 Lab 4
 */
class Lab04 extends Application {

    var $tabs = array('/lab04/' => 'Introduction', '/lab04/xml' => 'Our XML',
        '/lab04/dtd' => 'Our DTD');

    function __construct() {
        parent::__construct();
        $this->data['tabs'] = $this->tabs;
        $this->data['pagetitle'] = 'COMP4711 Lab 4 Solution';
    }

    /**
     * Default entry point.
     * No work to do - the story is told in the view.
     */
    function index() {
        $this->data['pagebody'] = 'lab04';
        $this->data['selected'] = '/lab04/';
        $this->data['validation'] = validate_xml($this->config->item('DATA_FOLDER').'tourism04.xml');
        $this->render();
    }

    /**
     * Subcontroller: dtd.
     * Display the DTD used to constrain out XML
     */
    function dtd() {
        $this->data['pagebody'] = '_data';
        $this->data['subtitle'] = 'DTD to constrain tourismXX.xml';
        $this->data['contents'] = display_file($this->config->item('DATA_FOLDER') . 'tourism.dtd');
        $this->data['selected'] = '/lab04/dtd';
        $this->render();
    }

    /**
     * Subcontroller: xml.
     * Display the XML data that we came up with
     */
    function xml() {
        $this->data['pagebody'] = '_data';
        $this->data['subtitle'] = 'Tourism XML bound to our DTD';
        $this->data['contents'] = display_file($this->config->item('DATA_FOLDER') . 'tourism04.xml');

        $this->data['selected'] = '/lab04/xml';
        $this->render();
    }

}

/* End of file lab04.php */
/* Location: ./application/controllers/lab04.php */