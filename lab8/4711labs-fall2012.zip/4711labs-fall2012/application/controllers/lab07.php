<?php

/**
 * Controller for COMP4711 Lab 7
 */
class Lab07 extends Application {

    var $tabs = array('/lab07/' => 'Introduction', '/lab07/report' => 'Report');

    /** Constructor - nothing exciting to see here */
    function __construct() {
        parent::__construct();
        $this->data['tabs'] = $this->tabs;
        $this->data['pagetitle'] = 'COMP4711 Lab 7 Solution';
        $this->data['category'] = '?';
        $this->data['total'] = '?';
        $this->load->model('tourism');
    }

    /**
     * Default entry point.
     * No work to do - the story is told in the view.
     */
    function index() {
        $this->data['pagebody'] = 'lab07';
        $this->data['selected'] = '/lab07/';
        $this->data['categories'] = $this->tourism->get_categories();
        $this->render();
    }

    /**
     * Subcontroller: work.
     * Process the category selection form, and ask the model for the total.
     */
    function work() {
        $requested = $this->input->post('requested');
        $this->data['category'] = $requested;
        $this->data['total'] = $this->tourism->get_total($requested);
        $this->index();
    }

    /**
     * Subcontroller: report.
     * Present the results of our processing the XML.
     * Note that the view has been dictated :(
     * Further note that the presentation data is now extracted inside our model
     */
    function report() {
        $this->data['pagebody'] = 'lab06table';
        $this->data = array_merge($this->data, $this->tourism->get_all());
        $this->data['selected'] = '/lab07/report';
        $this->render();
    }

}

/* End of file lab06.php */
/* Location: ./application/controllers/lab06.php */