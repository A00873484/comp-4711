<?php

/**
 * Controller for COMP4711 Lab 9
 */
class Lab09update extends Application {

    var $tabs = array('/lab09/' => 'Intro...', '/lab09upload' => 'Upload',
        '/lab09update' => 'Update');

    function __construct() {
        parent::__construct();
        $this->restrict('admin');
        $this->load->helper('display');
        $this->data['tabs'] = $this->tabs;
        $this->data['pagetitle'] = 'COMP4711 Lab 9 Solution';
        $this->load->model('tourism');
    }

    /**
     * Default entry point.
     */
    function index() {
        $this->data['pagebody'] = 'lab09update';
        $this->data['selected'] = '/lab09update';
        $this->session->set_flashdata('target', '/lab09upload');
        $this->session->set_flashdata('oops_target', '/lab09');
        if (isset($_POST)) $this->do_upload();
        $this->render();
    }

    /**
     * Process the upload using the CI file uploading class.
     * Make sure the uploads folder exists, with appropriate write permissions,
     * before attempting to use this.
     */
    function do_upload() {
        $config['upload_path'] = $this->config->item('DATA_FOLDER').'uploads/';
        $config['allowed_types'] = '*';
        $config['max_size'] = '0';
        $config['max_width'] = '0';
        $config['max_height'] = '0';
        $config['overwrite'] = TRUE;

         $this->load->library('upload', $config);

        if (!$this->upload->do_upload()) {
            $this->data['error'] = $this->upload->display_errors();
 //            $this->index(); // redisplay the form, with errors
        } else {
            $data = $this->upload->data();
            $filename = $data['full_path'];
            $this->tourism->process_upload($filename);
        }
        
    }

}

/* End of file lab09.php */
/* Location: ./application/controllers/lab09.php */