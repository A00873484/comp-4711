<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

require APPPATH . '/libraries/rest_controller.php';

/**
 * Default controller for the Products resource RESTful service
 */
class Product extends Rest_controller {

    function __construct() {
        parent::__construct();
    }

    function index_get() {
        $key = $this->get('code');
        if (!$key) {
            $this->response($this->products->getAll_array(), 200);
        } else {
            $result = $this->products->get($key);
            if ($result != null)
                $this->response($result, 200);
            else
                $this->response(array('error' => 'Product not found!'), 404);
        }
    }

    function index_post() {
        $key = $this->get('code');
        $record = array_merge(array('code' => $key), $_POST);
        $this->products->add($record);
        $this->response(array('ok'), 200);
    }

    function index_put() {
        $key = $this->get('code');
        $record = array_merge(array('code' => $key), $this->_put_args);
        $this->products->update($record);
        $this->response(array('ok'), 200);
    }

    function index_delete() {
        $key = $this->get('code');
        $this->products->delete($key);
        $this->response(array('ok'), 200);
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */