<?php

/**
 * core/MY_Controller.php
 *
 * Default application controller
 *
 * @author		JLP
 * @copyright           2010-2012, James L. Parry
 * ------------------------------------------------------------------------
 */
class Application extends CI_Controller {

    protected $data = array();      // parameters for view components
    protected $id;                  // identifier for our content

    const TICK = '<img src="/assets/images/tick.png"/>';

    protected $choices = array(// our menu navbar
        array("href" => "/welcome", "title" => "Welcome to COMP4711", "label" => "Home", "tick" => ""),
        array("href" => "/lab03", "title" => "XML document", "label" => "Lab #3 (XML)", "tick" => self::TICK),
        array("href" => "/lab04", "title" => "DTD constraints", "label" => "Lab #4 (DTD)", "tick" => self::TICK),
        array("href" => "/lab05", "title" => "Schema constraints", "label" => "Lab #5 (schema)", "tick" => self::TICK),
        array("href" => "/lab06", "title" => "SimpleXML processing", "label" => "Lab #6 (DOM)", "tick" => self::TICK),
        array("href" => "/lab07", "title" => "CodeIgniter model", "label" => "Lab #7 (Model)", "tick" => self::TICK),
        array("href" => "/lab08", "title" => "Add XPath expressions", "label" => "Lab #8 (XPath)", "tick" => self::TICK),
        array("href" => "/lab09", "title" => "Server-side processing and data mods", "label" => "Lab #9 (Server)", "tick" => self::TICK),
        array("href" => "/lab10", "title" => "XML-RPC client and server", "label" => "Lab #10 (RPC)", "tick" => self::TICK),
        array("href" => "/lab11", "title" => "REST and JSON", "label" => "Lab #11 (REST)", "tick" => self::TICK),
        array("href" => "/lab12", "title" => "Social media integration", "label" => "Lab #12 (Social)", "tick" => "")
    );

    /**
     * Constructor.
     * Establish view parameters & load common helpers
     */
    function __construct() {
        parent::__construct();
        $this->data = array();
        $this->data['title'] = 'COMP4711 Fall 2012 Solution';
        $this->data['errors'] = array();
        $this->load->library('session');
        $this->data['session_id'] = $this->session->userdata('session_id');
        $this->data['userID'] = $this->session->userdata('userID');
        $this->data['userName'] = $this->session->userdata('userName');
        $this->data['userRole'] = $this->session->userdata('userRole');
    }

    /**
     * Render this page
     */
    function render() {
        $this->data['choices'] = $this->choices;
        $this->data['menubar'] = $this->parser->parse('_menubar', $this->data, true);
        $this->data['secondary'] = $this->make_secondary();

        $this->data['content'] = $this->parser->parse($this->data['pagebody'], $this->data, true);
        $this->data['email'] = $this->properties->get('email');
        $this->data['instructor'] = $this->properties->get('instructor');
        $this->data['data'] = &$this->data;
        $this->parser->parse('_template', $this->data);
    }

    /**
     * Build the secondary (tabbed) menu 
     */
    function make_secondary() {
        if (!isset($this->data['tabs']))
            return "";

        $parms['tabs'] = array();
        foreach ($this->data['tabs'] as $link => $desc) {
            if ($this->data['selected'] == $link)
                $code = 'class="selected"';
            else
                $code = '';
            $parms['tabs'][] = array('link' => $link, 'desc' => $desc, 'selected' => $code);
        }
        return $this->parser->parse('_tabbed_menu', $parms, true);
    }

    /**
     * RBAC - role-based access control.
     * Restrict the access of a page to only those users
     * who have the role specified.
     * 
     * @param string $roleNeeded 
     */
    function restrict($roleNeeded = null) {
        $userRole = $this->session->userdata('userRole');
        if ($roleNeeded != null) {
            if ($userRole != $roleNeeded) {
                redirect("/");
                exit;
            }
        }
    }

    /**
     * Are we logged in? 
     */
    function loggedin() {
        return $this->session->userdata('userID');
    }
}

/* End of file MY_Controller.php */
/* Location: application/core/MY_Controller.php */