(function($) {
    $('.pgwSlider').pgwSlider();
})(jQuery);