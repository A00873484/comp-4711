<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-547bbdc4335f86dd" async="async"></script>
<p class="lead">
    Your Custom Travel Plan
</p>
<table class="table">
    <tr><td>From {source} to {destination}</td></tr>
    <tr>
        <td>Sails on</td>
        <td>Leaves</td>
        <td>Arrives</td>
        <td>Stops</td>
    </tr>
    {departures}
</table>