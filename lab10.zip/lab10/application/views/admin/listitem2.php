<tr>
	<td>{code}</td>
	<td>{name}</td>
	<td>{description}</td>
	<td><img src='/assets/images/{picture}' width='30px' height='30px'></td>
	<td><a href="/admin/edit4/{code}">Edit</a></td>
</tr>