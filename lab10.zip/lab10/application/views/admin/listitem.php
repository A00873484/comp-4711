<p class="lead">
    <a href="/order/neworder" class="btn btn-large btn-primary">Start a new order</a>    
</p>
<p>Order summary:</p>
<table class="table">
    <tr>
        <th>Code</th>
        <th>Name</th>
        <th>Description</th>
        <th>Picture</th>
		<th>Edit</th>
    </tr>
    {themeat}
</table>
