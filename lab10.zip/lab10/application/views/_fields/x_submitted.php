<div class="control-group">
    <label class="control-label" >Already uploaded</label>
    <div class="controls">
        <div class="fileupload fileupload-new" data-provides="fileupload">
            Image: <img src="/assets/images/{name}" alt="{label}" border="0" width="{width} height={height}"/>
        </div>
    </div>
</div>

