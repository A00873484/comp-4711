Daniel Engelhard, Jay Huang 

first task
	On the Homepage I added the Like, Share, and Follow buttons that would make you like, share or follow bcit.

second task 
	When you clicked the Lab7 button on the homepage you get to the page where the twitter follow button is clicking the 		button would make you follow bcit on twitter

third task
	after you clicked the submit button on the page with the twitter follow button you get to a page where you can share 		the contents of the page using facebook, twitter, or email. And you can print out the contents using another button
	(allowing you to print/share the departure schedule you just created) all such buttons are located on the right side 		of the screen, found at "https://www.addthis.com/get/sharing" where I picked the free sharing sidebar

fourth task
	in the front page you can click the lab5 button that leads you to a page with the ability to share the page contents 		with facebook, twitter, linkedin, and email. Located right under the header.  
	I went to "http://www.sharethis.com/get-sharing-tools/#" to get the share buttons and excluded the pininterest, and 		sharethis buttons since the site dosnt have anthing of relation to these things 