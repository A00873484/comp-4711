Daniel Engelhard, Jay Huang

first view is finished 
second view is a prototype

Model not connected to Controller so has model functions.

was able extract data from the xml document

Controllers not finished either 