Start<br>
<select id="select" name="start" style="width: 115px;">
	{locations}
	<option value="{id}">{name}</option>
	{/locations}
</select><br><br>
End<br>
<select id="select" name="end" style="width: 115px;">
	{locations}
	<option value="{id}">{name}</option>
	{/locations}
</select><br><br>
<input type="submit" value="Submit Changes">
<p>Welcome to Trip Planner! To plan your trip, click on Plan trip above</p>
