<?php
/*
 * Menu navbar, just an unordered list
 */
?>
<ul class="nav">
    <li href="/">Home</li>
</ul>
